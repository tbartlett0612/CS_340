from pymongo import MongoClient

class AnimalShelter(object):

    def __init__(self):
        # Initializing the MongoClient. This helps to 
        # access the MongoDB databases and collections.
        # This is hard-wired to use the aac database, the 
        # animals collection, and the aac user.
        # Definitions of the connection string variables are
        # unique to the individual Apporto environment.
        #
        # You must edit the connection variables below to reflect
        # your own instance of MongoDB!
        #
        #
        # Initialize Connection
        USER = 'aacuser'
        PASS = 'mypass'
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 31392
        DB = 'AAC'
        COL = 'animals'
        #
        self.client = MongoClient('mongodb://%s:%s@%s:%s' % (USER, PASS, HOST, PORT))
        self.database = self.client['%s' % (DB)]
        self.collection = self.database['%s' % (COL)]

# Complete this create method to implement the C in CRUD.
    def create(self, data):
        if data is not None:
            success = self.database.animals.insert_one(data)  # data should be dictionary
            #Check success for completion
            if success != 0:
                return True
            #default return
            return False
        else:
            raise Exception("Nothing to save, because data parameter is empty")

# Create method to implement the R in CRUD.
    def read(self, criteria):
        if criteria:
            data = self.database.animals.find(criteria, {"_id": False})
        else:
            data = self.database.animals.find( {}, {"_id": False})
        return data
    
#Method to update
    def update(self, searchCriteria, updateCriteria):
        if searchCriteria is not None:
            result = self.database.animals.update_many(searchCriteria, { "$set": updateCriteria})
        else:
            return "{}"
        return result.raw_result

#Method to delete
    def delete(self, deleteCriteria):
        if deleteCriteria is not None:
            result = self.database.animals.delete_many(deleteCriteria)
        else:
            return "{}"
        return result.raw_result